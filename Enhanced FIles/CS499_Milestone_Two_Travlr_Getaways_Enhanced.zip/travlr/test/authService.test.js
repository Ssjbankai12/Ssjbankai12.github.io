const chai = require('chai');
const sinon = require('sinon');
const expect = chai.expect;

const authService = require('../app_api/services/authService');
const User = require('../app_api/models/user');

describe('authService', () => {
    afterEach(() => {
        sinon.restore();
    });

    describe('validateRegistrationInput', () => {
        it('returns true when name, email, and password are all present', () => {
            const result = authService.validateRegistrationInput({
                name: 'Kevin Korb',
                email: 'kevin@example.com',
                password: 'secret123'
            });

            expect(result).to.be.true;
        });

        it('returns false when a required field is missing', () => {
            const result = authService.validateRegistrationInput({
                name: 'Kevin Korb',
                email: 'kevin@example.com'
            });

            expect(result).to.be.false;
        });
    });

    describe('validateLoginInput', () => {
        it('returns true when email and password are both present', () => {
            const result = authService.validateLoginInput({
                email: 'kevin@example.com',
                password: 'secret123'
            });

            expect(result).to.be.true;
        });

        it('returns false when password is missing', () => {
            const result = authService.validateLoginInput({
                email: 'kevin@example.com'
            });

            expect(result).to.be.false;
        });
    });

    describe('registerUser', () => {
        it('hashes the password, saves the user, and returns a signed JWT', async () => {
            const fakeToken = 'signed.jwt.token';
            sinon.stub(User.prototype, 'setPassword');
            sinon.stub(User.prototype, 'save').resolves(true);
            sinon.stub(User.prototype, 'generateJWT').returns(fakeToken);

            const token = await authService.registerUser({
                name: 'Kevin Korb',
                email: 'kevin@example.com',
                password: 'secret123'
            });

            expect(token).to.equal(fakeToken);
        });

        it('throws an error when the save fails', async () => {
            sinon.stub(User.prototype, 'setPassword');
            sinon.stub(User.prototype, 'save').resolves(null);

            let caughtError = null;
            try {
                await authService.registerUser({
                    name: 'Kevin Korb',
                    email: 'kevin@example.com',
                    password: 'secret123'
                });
            } catch (err) {
                caughtError = err;
            }

            expect(caughtError).to.not.be.null;
            expect(caughtError.message).to.equal('Unable to save user');
        });
    });
});
