const chai = require('chai');
const sinon = require('sinon');
const mongoose = require('mongoose');
const expect = chai.expect;

require('../app_api/models/travlr');
const Model = mongoose.model('trips');
const tripsService = require('../app_api/services/tripsService');

describe('tripsService', () => {
    afterEach(() => {
        sinon.restore();
    });

    it('getAllTrips returns every trip in the collection', async () => {
        const fakeTrips = [{ code: 'GALL', name: 'Gallery Tour' }];
        sinon.stub(Model, 'find').returns({ exec: sinon.stub().resolves(fakeTrips) });

        const result = await tripsService.getAllTrips();

        expect(result).to.deep.equal(fakeTrips);
    });

    it('getTripByCode filters the query by the given trip code', async () => {
        const fakeTrip = [{ code: 'GALL', name: 'Gallery Tour' }];
        const findStub = sinon.stub(Model, 'find').returns({ exec: sinon.stub().resolves(fakeTrip) });

        const result = await tripsService.getTripByCode('GALL');

        expect(findStub.calledWith({ code: 'GALL' })).to.be.true;
        expect(result).to.deep.equal(fakeTrip);
    });

    it('createTrip builds and saves a new trip document', async () => {
        const saveStub = sinon.stub(Model.prototype, 'save').resolves({ code: 'NEW1', name: 'New Trip' });

        const result = await tripsService.createTrip({ code: 'NEW1', name: 'New Trip' });

        expect(saveStub.calledOnce).to.be.true;
        expect(result).to.deep.equal({ code: 'NEW1', name: 'New Trip' });
    });

    it('updateTrip calls findOneAndUpdate with the trip code and new data', async () => {
        const updateStub = sinon
            .stub(Model, 'findOneAndUpdate')
            .returns({ exec: sinon.stub().resolves({ code: 'GALL', name: 'Updated Name' }) });

        const result = await tripsService.updateTrip('GALL', { name: 'Updated Name' });

        expect(updateStub.calledOnce).to.be.true;
        expect(updateStub.firstCall.args[0]).to.deep.equal({ code: 'GALL' });
        expect(result.name).to.equal('Updated Name');
    });

    it('updateTrip resolves to null when no matching trip exists', async () => {
        sinon.stub(Model, 'findOneAndUpdate').returns({ exec: sinon.stub().resolves(null) });

        const result = await tripsService.updateTrip('DOESNOTEXIST', { name: 'Updated Name' });

        expect(result).to.be.null;
    });
});
