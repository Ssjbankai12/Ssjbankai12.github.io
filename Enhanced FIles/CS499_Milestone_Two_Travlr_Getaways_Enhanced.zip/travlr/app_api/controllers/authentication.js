const passport = require('passport');
const authService = require('../services/authService');

const register = async (req, res) => {
    // Validate that all required parameters are present
    if (!authService.validateRegistrationInput(req.body)) {
        return res
            .status(400)
            .json({ message: "All fields required" });
    }

    try {
        const token = await authService.registerUser(req.body);
        return res
            .status(200)
            .json(token);
    } catch (err) {
        return res
            .status(400)
            .json({ message: "Unable to register user" });
    }
};

const login = (req, res) => {
    // Validate that email and password are present
    if (!authService.validateLoginInput(req.body)) {
        return res
            .status(400)
            .json({ message: "All fields required" });
    }

    // Delegate authentication to passport module
    passport.authenticate('local', (err, user, info) => {
        if (err) {
            // Error in Authentication Process
            return res
                .status(404)
                .json(err);
        }
        if (user) {
            // Auth succeeded - generate JWT and return to caller
            const token = user.generateJWT();
            return res
                .status(200)
                .json({ token });
        } else {
            // Auth failed return error
            return res
                .status(401)
                .json(info);
        }
    })(req, res);
};

// Export methods that drive endpoints.
module.exports = {
    register,
    login
};
