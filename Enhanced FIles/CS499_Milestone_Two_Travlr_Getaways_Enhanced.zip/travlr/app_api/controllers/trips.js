const tripsService = require('../services/tripsService');

// GET: /trips - list all the trips
const tripsList = async (req, res) => {
    const q = await tripsService.getAllTrips();

    if (!q) {
        return res
            .status(404)
            .json({ message: "No trips found" });
    } else {
        return res
            .status(200)
            .json(q);
    }
};

// GET: /trips/:tripCode - find a single trip by its code
const tripsFindByCode = async (req, res) => {
    const q = await tripsService.getTripByCode(req.params.tripCode);

    if (!q) {
        return res
            .status(404)
            .json({ message: "No trips found" });
    } else {
        return res
            .status(200)
            .json(q);
    }
};

// POST: /trips - Adds a new Trip
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsAddTrip = async (req, res) => {
    try {
        const q = await tripsService.createTrip(req.body);
        return res
            .status(201)
            .json(q);
    } catch (err) {
        return res
            .status(400)
            .json({ message: "Unable to add trip" });
    }
};

// PUT: /trips/:tripCode - Updates an existing Trip
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsUpdateTrip = async (req, res) => {
    try {
        const q = await tripsService.updateTrip(req.params.tripCode, req.body);

        if (!q) {
            return res
                .status(400)
                .json({ message: "Trip not found" });
        } else {
            return res
                .status(201)
                .json(q);
        }
    } catch (err) {
        return res
            .status(400)
            .json({ message: "Unable to update trip" });
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip
};
