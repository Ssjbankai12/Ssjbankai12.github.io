//bring db connection and the trip schema
const Mongoose = require('./db');
const Trip = require('./travlr');

//read seed data from the JSON file
var fs = require('fs');
var trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf8'));

//delete any existing recors, then insert seed data
const seedDB = async () => {
    await Trip.deleteMany({});
    await Trip.insertMany(trips);
};

//close the mongodb connection and exit
seedDB().then(async () => {
    await Mongoose.connection.close();
    process.exit(0);
});