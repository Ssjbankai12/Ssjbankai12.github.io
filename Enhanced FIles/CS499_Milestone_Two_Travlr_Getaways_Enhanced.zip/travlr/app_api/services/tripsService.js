const mongoose = require('mongoose');
const Trip = require('../models/travlr');
const Model = mongoose.model('trips');

// Returns every trip in the collection
async function getAllTrips() {
    return Model.find({}).exec();
}

// Returns the trip(s) matching the given trip code
async function getTripByCode(tripCode) {
    return Model.find({ code: tripCode }).exec();
}

// Creates and saves a new trip document
async function createTrip(tripData) {
    const newTrip = new Trip({
        code: tripData.code,
        name: tripData.name,
        length: tripData.length,
        start: tripData.start,
        resort: tripData.resort,
        perPerson: tripData.perPerson,
        image: tripData.image,
        description: tripData.description
    });

    return newTrip.save();
}

// Updates an existing trip identified by trip code
async function updateTrip(tripCode, tripData) {
    return Model.findOneAndUpdate(
        { code: tripCode },
        {
            code: tripData.code,
            name: tripData.name,
            length: tripData.length,
            start: tripData.start,
            resort: tripData.resort,
            perPerson: tripData.perPerson,
            image: tripData.image,
            description: tripData.description
        }
    ).exec();
}

module.exports = {
    getAllTrips,
    getTripByCode,
    createTrip,
    updateTrip
};
