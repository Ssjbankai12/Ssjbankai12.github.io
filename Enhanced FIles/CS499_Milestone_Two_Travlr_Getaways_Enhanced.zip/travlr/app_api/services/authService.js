const User = require('../models/user');

// Confirms all required fields are present for registration
function validateRegistrationInput(body) {
    return !!(body.name && body.email && body.password);
}

// Confirms all required fields are present for login
function validateLoginInput(body) {
    return !!(body.email && body.password);
}

// Creates a new user, hashes their password, saves the record,
// and returns a signed JWT for the new account
async function registerUser(userData) {
    const user = new User({
        name: userData.name,
        email: userData.email,
        password: ''
    });
    user.setPassword(userData.password);

    const saved = await user.save();
    if (!saved) {
        throw new Error('Unable to save user');
    }

    return user.generateJWT();
}

module.exports = {
    validateRegistrationInput,
    validateLoginInput,
    registerUser
};
